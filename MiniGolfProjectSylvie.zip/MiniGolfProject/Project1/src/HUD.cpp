#include "HUD.h"

using namespace std;

/*

void buildSplash() {
	//will build the background image by pushing individual verts and color as shown:
	splashVerts.push_back(3);
	splashVerts.push_back(2);
	splashVerts.push_back(5);
	splashColor.push_back(0.5f);
	splashColor.push_back(0.4f);
	splashColor.push_back(0.4f);

	//the last few coordinates will be the two options, one player and two player
}

void buildHUD() {
	//this will build the HUD that will be shown on the game screen
}*/