//ResourceManger.h

#pragma once

#include <vector>
#include "Tee.h"
#include "Cup.h"
#include "Physics.h"
#include "Vector3.h"

using namespace std;

class ResourceManager {

	private:
		vector<Tile> tiles;
		vector<float> levelVerts;
		vector<float> levelNorms;
		vector<float> levelColor;
		vector<float> wallVerts;
		vector<float> wallNorms;
		vector<float> wallColor;

		int numLevelVerts, numLevelNorms, numWallVerts, numWallNorms;
		int numLevelColors, numWallColors;

		//void pushNorms(int tileInd, int vertexInd, bool wallNorms);
		void buildArrays();
		void buildTiles();
		//void buildWalls();
		void addTile(Tile &newTile);
		void addCup(Cup &newCup);
		void addTee(Tee &newTee);

	public:
		ResourceManager();
		ResourceManager(Ball* ball);
		~ResourceManager();

		Ball* ball;
		Cup cup;
		Tee tee;

		void readFile(char* inputFile);
		vector<float> getLevelVerts(){return levelVerts;}
		vector<float> getLevelNorms(){return levelNorms;}
		vector<float> getLevelColor(){return levelColor;}
		vector<float> getWallVerts(){return wallVerts;}
		vector<float> getWallNorms(){return wallNorms;}
		vector<float> getWallColor(){return wallColor;}

		int getNumLevelVerts(){return numLevelVerts;}
		int getNumLevelNorms(){return numLevelNorms;}
		int getNumLevelColor(){return numLevelColors;}
		int getNumWallVerts(){return numWallVerts;}
		int getNumWallNorms(){return numWallNorms;}
		int getNumWallColor(){return numWallColors;}
		
		vector<Tile> tileList();
		Ball* getBall(){return ball;}
		Tee getTee(){return tee;}
		Cup getCup(){return cup;}

		Tile getTile(int id);
		Tile getTile(Vector3* pos, Physics* physics);
};