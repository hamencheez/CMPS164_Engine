//Ball.h
#pragma once

#include "Vector3.h"
#include "Tile.h"
#include "../GL/freeglut.h"

class Ball {
private:
	
public:
	float groundOffset;
	float aim;
	Vector3 *position; 
	Vector3 *velocity;
	Vector3 *initialPosition;
	bool isMoving;

	Ball(void){};
	~Ball(void){};

	Ball(float x, float y, float z) {
		groundOffset = 0.1;
		position = new Vector3(x, y, z);
		velocity = new Vector3(0.05, 0.0, -0.04);
		initialPosition = new Vector3(*position);
		isMoving = false;
	}

	void initialize(float x, float y, float z){
		groundOffset = 0.1;
		position = new Vector3(x, y, z);
		velocity = new Vector3(0.05, 0.0, -0.04);
		initialPosition = new Vector3(*position);
		isMoving = false;
	}

	//untested
	void update(float y, Vector3 *down) {
		//If the ball is moving, simply update it
		if (isMoving) {
			position = position->add(velocity);
			position->setY(y);
			if ((velocity->getLength() < 0.01) && (down->getLength() == 0)) { 
				isMoving = false;
				velocity = new Vector3(0.05, 0.0, -0.03);
			}
		}
	}

	//untested
	void launchBall() {
		isMoving = true;
		//aim += 35;
		aim = (aim * 3.1415926) / 180;
		aim *= -1;
		Vector3 *newVelocity = new Vector3((velocity->getX() * cos(aim)) - (velocity->getZ() * sin(aim)), 0, (velocity->getX() * sin(aim)) + (velocity->getZ() * cos(aim)));
		velocity = newVelocity;
	}

	//untested
	void resetBall() {
		isMoving = false;
		position = new Vector3(*initialPosition);
		velocity = new Vector3(0.05, 0.0, -0.03);
		aim = 0.0;
	}

};