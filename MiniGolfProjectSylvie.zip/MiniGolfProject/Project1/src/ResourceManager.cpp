
#include "ResourceManager.h"

#include <iostream>
#include <fstream>

using namespace std;

ResourceManager::ResourceManager() {
	//Fill in if you need to
}

ResourceManager::ResourceManager(Ball* newBall) {
	ball = newBall;
}

void ResourceManager::addTile(Tile &newTile) {
	tiles.push_back(newTile);
}

void ResourceManager::addCup(Cup &newCup) {
	cup = newCup;
}

void ResourceManager::addTee(Tee &newTee) {
	tee = newTee;
}

std::vector<Tile> ResourceManager::tileList() {
	return tiles;
}

//untested, can't imagine this not working though
Tile ResourceManager::getTile(int id) {
	for (int itor = 0; itor < tiles.size(); ++itor) {
		if (tiles.at(itor).tileIndex) return tiles.at(itor);
	}
	cerr <<"Tile ID not recognized" << endl;
	exit(-1);
}

//untested
Tile ResourceManager::getTile(Vector3* pos, Physics* physics) {
	bool inPolygon = false;
	float minY = 99999;
	float maxY = -99999;

	for (unsigned int itor = 0; itor < tiles.size(); ++itor) {
		if (physics->pointOnPlane(tiles.at(itor).xVertex, tiles.at(itor).zVertex, pos->getX(), pos->getZ())) {
		
			for (int x = 0; x < tiles.at(itor).yVertex.size(); ++x) {
				if (tiles.at(itor).yVertex.at(x) < minY) minY = tiles.at(itor).yVertex.at(x);
				if (tiles.at(itor).yVertex.at(x) > maxY) maxY = tiles.at(itor).yVertex.at(x);
			}
			if ((pos->getY() >= minY - 0.03) && (pos->getY() <= maxY + 0.03)) 
				return tiles.at(itor);
		}
	}

	std::cout << "Tile not found" <<std::endl;
	
	//Return first tile
	return tiles.at(0);
}

//iterates through tile list, building all of the necessary verts
//then initializes ball
void ResourceManager::buildArrays(){
	levelVerts = levelNorms = levelColor = wallVerts = wallNorms = wallColor= vector<float>();
	vector<float> activeVec = vector<float>();

	for(int i = 0; i < tiles.size(); i++){
		tiles[i].buildAll();
		activeVec = tiles[i].getTVerts();
		levelVerts.insert(levelVerts.end(), activeVec.begin(), activeVec.end());
		activeVec = tiles[i].getTNorms();
		levelNorms.insert(levelNorms.end(), activeVec.begin(), activeVec.end());
		activeVec = tiles[i].getTColor();
		levelColor.insert(levelColor.end(), activeVec.begin(), activeVec.end());
		activeVec = tiles[i].getWVerts();
		wallVerts.insert(wallVerts.end(), activeVec.begin(), activeVec.end());
		activeVec = tiles[i].getWNorms();
		wallNorms.insert(wallNorms.end(), activeVec.begin(), activeVec.end());
		activeVec = tiles[i].getWColor();
		wallColor.insert(wallColor.end(), activeVec.begin(), activeVec.end());
	}

	numLevelVerts = levelVerts.size();
	numLevelNorms = levelNorms.size();
	numLevelColors = levelColor.size();
	numWallVerts = wallVerts.size();
	numWallNorms = wallNorms.size();
	numWallColors = wallColor.size();

	ball->initialize(tee.x, tee.y, tee.z);
}

void ResourceManager::readFile(char* filename) {	
	FILE * f;
	string line;
	char word[80];

	int tileInd, numVerts, neighbor;
	float x, y, z;

	f = fopen (filename, "r");

	if (f!=NULL)
	 {
	  while(fscanf(f, "%s", &word) > 0){
		  if(strcmp(word, "tile") == 0){
			  fscanf(f, "%d %d ", &tileInd, &numVerts);
			  Tile newTile = Tile(tileInd, numVerts);
			  for(int i = 0; i < numVerts; i++){
				  fscanf(f, "%f %f %f", &x, &y, &z);
				  newTile.addVert(x, y, z);
			  }
			  for(int i = 0; i < numVerts; i++){
				  fscanf(f, "%d", &neighbor);
				  newTile.addNeighbor(neighbor);
			  }
			  addTile(newTile);
		  } else if(strcmp(word, "cup") == 0){
			  fscanf(f, "%d %f %f %f", &tileInd, &x, &y, &z);
			  Cup newCup = Cup(tileInd, x, y, z);
			  cup = newCup;
		  } else if(strcmp(word, "tee") == 0){
			  fscanf(f, "%d %f %f %f", &tileInd, &x, &y, &z);
			  Tee newTee = Tee(tileInd, x, y, z);
			  tee = newTee;
		  } else{
			  cout << "Do not recognize tile type" << endl;
			  exit(-1);
		  }
	  }
    fclose (f);
	}
	buildArrays();
}