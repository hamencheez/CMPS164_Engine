
#include "Vector3.h"
#include <math.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>

Vector3::Vector3(float xPos, float yPos, float zPos) {
	x = xPos;
	y = yPos;
	z = zPos;
}

float Vector3::getLength() {
	return (sqrt((this->x * this->x) + (this->y * this->y) + (this->z * this->z)));
}

float Vector3::dot(Vector3 *v) {
	float result = (this->x * v->x) + (this->y * v->y) + (this->z * v->z);
	return result;
}

Vector3* Vector3::cross(Vector3 *v) {
	float x, y, z;
	x = (this->y * v->z) - (this->z * v->y);
	y = (this->z * v->x) - (this->x * v->z);
	z = (this->x * v->y) - (this->y * v->x);
	//printf("\ncross product of");
	//this->print();
	//printf("and");
	//v->print();
	//printf("equals");
	Vector3 *result = new Vector3(x, y, z);
	//result->print();
	return result;
}

Vector3* Vector3::add(Vector3 *v) {
	float a, b, c;
	printf("\nfirst to add:");
	print();
	printf("\nsecond to add:");
	v->print();
	a = this->x + v->x;
	b = this->y + v->y;
	c = this->z + v->z;
	Vector3 *result = new Vector3(a, b, c);
	printf("\nresult add:");
	result->print();
	return result;
}

Vector3* Vector3::subtract(Vector3 *v) {
	float a, b, c;
	a = this->x - v->x;
	b = this->y - v->y;
	c = this->z - v->z;
	Vector3 *result = new Vector3(a, b, c);
	return result;
}

Vector3* Vector3::normalize() {
	float x, y, z;
	float length = this->getLength();
	if (length == 0) return new Vector3(0, 0, 0);
	x = this->x / length;
	y = this->y / length;
	z = this->z / length;
	Vector3 *result = new Vector3(x, y, z);
	return result;
}

Vector3* Vector3::multiply(float value) {
	Vector3 *result = new Vector3(this->x * value, this->y * value, this->z * value);
	return result;
}

float Vector3::getX() {
	return this->x;
}

float Vector3::getY() {
	return this->y;
}

float Vector3::getZ() {
	return this->z;
}

void Vector3::setPos(float xVal, float yVal, float zVal) {
	x = xVal;
	y = yVal;
	z = zVal;
}

void Vector3::setX(float value) {
	x = value;
}

void Vector3::setY(float value) {
	y = value;
}

void Vector3::setZ(float value) {
	z = value;
}

void Vector3::print() {
	printf("\nX: %hf\nY: %f\nZ: %f\n", x, y, z);
}