/*
 * File: main.cxx
 * Description: A simple OpenGL program utilizing vertex and fragment shaders.
 *
 *  Created on: Apr 2, 2012
 *      Author: Nathaniel Cesario
 */

#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/gl.h>

#include "SOIL.h"
#include "ImageUtilsGL.hpp"

#define GLM_SWIZZLE
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_access.hpp>


#include <cmath>

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <fstream>
using namespace std;

#define MAX_PTS 40
#define MAXFLOAT ((float)3.40282346638528860e+38) // taken from math.h
#define MINFLOAT (-MAXFLOAT)


/**
 * Simple class for keeping track of shader program and vertex attribute
 * locations.
 */
class Shader {
public:
    Shader(string vertFile, string fragFile) { fromFiles(vertFile, fragFile); }

    /**
     * Creates a shader program based on vertex and fragment source.
     *
     * @param vertFile Path to vertex source
     * @param fragFile Path to fragment source
     */
    void fromFiles(string vertFile, string fragFile) {
        //These are shader objects containing the shader source code
        GLint vSource = setShaderSource(vertFile, GL_VERTEX_SHADER);
        GLint fSource = setShaderSource(fragFile, GL_FRAGMENT_SHADER);

        //Create a new shader program
        program = glCreateProgram();

        //Compile the source code for each shader and attach it to the program.
        glCompileShader(vSource);
        printLog("vertex compile log: ", vSource);
        glAttachShader(program, vSource);

        glCompileShader(fSource);
        printLog("fragment compile log: ", fSource);
        glAttachShader(program, fSource);

        //we could attach more shaders, such as a geometry or tessellation
        //shader here.

        //link all of the attached shader objects
        glLinkProgram(program);
    }

    /**
     * Helper method for reading in the source for a shader and creating a
     * shader object.
     *
     * @param file Filename of shader source
     * @param type Type of shader-> Only GL_VERTEX_SHADER and GL_FRAGMENT_SHADER
     *   are supported here.
     */
    GLint setShaderSource(string file, GLenum type) {
        //read source code
        ifstream fin(file.c_str());
        if (fin.fail()) {
            cerr << "Could not open " << file << " for reading" << endl;
            return -1;
        }
        fin.seekg(0, ios::end);
        int count  = fin.tellg();
        char *data = NULL;
        if (count > 0) {
            fin.seekg(ios::beg);
            data = new char[count+1];
            fin.read(data,count);
            data[count] = '\0';
        }
        fin.close();

        //create the shader
        GLint s = glCreateShader(type);
        glShaderSource(s, 1, const_cast<const char **>(&data), NULL);
        delete [] data;
        return s;
    }

    /**
     * Helper function used for debugging.
     */
    void printLog(std::string label, GLint obj) {
        int infologLength = 0;
        int maxLength;

        if(glIsShader(obj)) {
            glGetShaderiv(obj,GL_INFO_LOG_LENGTH,&maxLength);
        } else {
            glGetProgramiv(obj,GL_INFO_LOG_LENGTH,&maxLength);
        }

        char infoLog[maxLength];

        if (glIsShader(obj)) {
            glGetShaderInfoLog(obj, maxLength, &infologLength, infoLog);
        } else {
            glGetProgramInfoLog(obj, maxLength, &infologLength, infoLog);
        }

        if (infologLength > 0) {
            cerr << label << infoLog << endl;
        }
    }

    GLint program; //shader program
    GLint modelViewLoc; //location of the modelview matrix in the program (M)
    GLint projectionLoc; //location of the projection matrix in the program (P)
    GLint normalMatrixLoc; //location of the normal matrix in the program (M_n)
    GLint useLight, userColor; //uniform for blocking lighting for axes
    GLint vertexLoc, normalLoc; //vertex attribute locations (pos and norm)
      //respectively
    GLint colorLoc; //Model color
    GLint indexLoc;
    GLint timeLoc; //location of time variable
    GLint texCoordLoc;
    GLint lightPosLoc;
    GLint viewPosLoc;
    GLuint vertexBuffer, normalBuffer, colorBuffer, texBuffer, texArray; //used to keep track of GL buffer objects
    GLuint indexBuffer, axesBuffer, aNormalBuffer, aColorBuffer; //index, axes, and axes colors
};
Shader *shader = NULL;

int WIN_WIDTH = 1280, WIN_HEIGHT = 720; //window width/height
glm::mat4 modelView, projection, camera, defaultView, defaultView2, axisView; //matrices for shaders
glm::vec3 lightPos(0,0,1), viewPos(10,10,10);
float animTime = 0.0f, deltaT = 0.0001; //variables for animation

vector<float> verts;
vector<float> verts2; //vertex array
vector<float> norms;
vector<float> aNorms;
vector<float> sNorms;
vector<float> axes;
vector<float> texs;
vector<float> color; //Model color array
vector<float> aColor; //Axis and Bounding Box color array
vector<unsigned short> indices;
size_t numVerts; //number of total vertices
size_t numIndex;
size_t numAxes;

map<int,glm::vec3> normMap;
map<int,glm::vec3>::iterator it;

UBTextureGL texture;

glm::vec3 minpt;
glm::vec3 maxpt;
glm::vec3 centerpt;

bool block;

bool xSelect, ySelect, zSelect, scaleSelect, cameraSelect;
bool mouseDownL, mouseDownR, bBox, smoothShade;
int numCoords, numPolygons;
int downX, downY, upX, upY, currX, currY;
int oldX, oldY;
float factorTrans = 0.05f;
float factorRot = .4f;
float factorScale = .01f;

//updates values based on some change in time
void update(float dt) {
    animTime += dt;

    modelView = glm::rotate(modelView, glm::float_t(0.01), glm::vec3(1,1,0));
}

//reshape function for GLUT
void reshape(int w, int h) {
    WIN_WIDTH = w;
    WIN_HEIGHT = h;
    projection = glm::perspective(
            glm::float_t(45),
            glm::float_t(WIN_WIDTH) / glm::float_t(WIN_HEIGHT),
            glm::float_t(0.1),
            glm::float_t(1000.0)
    );
}

void translate()
{
	if(xSelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect){
				glm::vec3 pt = glm::vec3(factorTrans*(currX-oldX), 0.0f, 0.0f);

				camera = glm::translate(camera, pt );
			}
			else{
				glm::vec3 pt = glm::vec3(factorTrans*(currX-oldX), 0.0f, 0.0f);

				modelView = glm::translate(modelView, pt );
			}
		}
		oldX = currX;
	}
	if(ySelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect){
				glm::vec3 pt = glm::vec3(0.0f, factorTrans*(currX-oldX), 0.0f);

				camera = glm::translate(camera, pt );
			}
			else{
				glm::vec3 pt = glm::vec3(0.0f, factorTrans*(currX-oldX), 0.0f);

				modelView = glm::translate(modelView, pt );
			}
		}
		oldX = currX;
	}
	if(zSelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect){
				glm::vec3 pt = glm::vec3(0.0f, 0.0f , factorTrans*(currX-oldX));

				camera = glm::translate(camera, pt );
			}
			else{
				glm::vec3 pt = glm::vec3(0.0f, 0.0f, factorTrans*(currX-oldX));

				modelView = glm::translate(modelView, pt );
			}
		}
		oldX = currX;
	}
}
//Handles rotation of the surfboard or the camera
void rotate()
{
	if(xSelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect) camera = glm::rotate(camera, factorRot*(currX-oldX), glm::vec3(1.0f, 0.0f, 0.0f));
			else modelView = glm::rotate(modelView, factorRot*(currX-oldX), glm::vec3(1.0f, 0.0f, 0.0f));
		}
		oldX = currX;
	}
	if(ySelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect) camera = glm::rotate(camera, factorRot*(currX-oldX), glm::vec3(0.0f, 1.0f, 0.0f));
			else modelView = glm::rotate(modelView, factorRot*(currX-oldX), glm::vec3(0.0f, 1.0f, 0.0f));
		}
		oldX = currX;
	}
	if(zSelect) {
		if(oldX != 0 && currX!=0){
			if(cameraSelect) camera = glm::rotate(camera, factorRot*(currX-oldX), glm::vec3(0.0f, 0.0f, 1.0f));
			else modelView = glm::rotate(modelView, factorRot*(currX-oldX), glm::vec3(0.0f, 0.0f, 1.0f));
		}
		oldX = currX;
	}
}
//Handles scaling of the surfboard or the camera
void scale()
{
	if(cameraSelect){
		if(oldY != 0 && currY!=0){

			if(currY-oldY > 0) {
				glm::vec3 pt = glm::vec3(factorScale*(currY-oldY) + 1.0f, factorScale*(currY-oldY) + 1.0f, factorScale*(currY-oldY) + 1.0f);

				camera = glm::scale(camera, pt );
			}
			if(currY-oldY < 0) {
				glm::vec3 pt = glm::vec3(1.0f+factorScale*(currY-oldY), 1.0f+factorScale*(currY-oldY), 1.0f+factorScale*(currY-oldY));

				camera = glm::scale(camera, pt);
			}
		}
		oldY = currY;
	}
	else {
		if(oldX != 0 && currX!=0){

			if(currX-oldX < 0) {
				glm::vec3 pt = glm::vec3(factorScale*(currX-oldX) + 1.0f, factorScale*(currX-oldX) + 1.0f, factorScale*(currX-oldX) + 1.0f);

				modelView = glm::scale(modelView, pt );
			}
			if(currX-oldX > 0) {
				glm::vec3 pt = glm::vec3(1.0f+factorScale*(currX-oldX), 1.0f+factorScale*(currX-oldX), 1.0f+factorScale*(currX-oldX));

				modelView = glm::scale(modelView, pt);
			}
		}
		oldX = currX;
	}
}
//Called during every call to display and handles whether the surfboard or camera
//needs to translate, rotate, or scale
void checkMouse()
{
	if(mouseDownL && !scaleSelect) translate();
	else if(mouseDownL && scaleSelect) scale();
	else if(mouseDownR) rotate();
	else if(!mouseDownL && !mouseDownR)	oldX = 0;
}
//display function for GLUT
void display() {
    glViewport(0,0,WIN_WIDTH,WIN_HEIGHT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    checkMouse();

    axisView = defaultView;
    //Setup the modelview matrix
    //Mat4x4F modelCam = camera * modelView;
    glm::mat4 modelCam = camera * modelView;

    //grab the normal matrix from the modelview matrix (upper 3x3 entries of
    //modelview).
    glm::mat3 normalMatrix(modelCam);
    normalMatrix = glm::inverse(normalMatrix);
    normalMatrix = glm::transpose(normalMatrix);

    //Tell OpenGL which shader program we want to use. In this case, we are only
    //using one, but in general we might have many shader programs.
    glUseProgram(shader->program);

    //Pass the matrices and animation time to GPU
    glUniformMatrix4fv(
            shader->modelViewLoc, //handle to variable in the shader program
            1, //how many matrices we want to send
            GL_FALSE, //transpose the matrix
            glm::value_ptr(modelCam) //a pointer to an array containing the entries for
              //the matrix
            );
    glUniformMatrix4fv(shader->projectionLoc, 1, GL_FALSE,
            glm::value_ptr(projection));
    glUniformMatrix3fv(shader->normalMatrixLoc, 1, GL_FALSE,
            glm::value_ptr(normalMatrix));
    glUniform1f(shader->timeLoc, animTime);
    glUniform3fv(shader->lightPosLoc, 1, glm::value_ptr(lightPos));
    glUniform3fv(shader->viewPosLoc, 1, glm::value_ptr(viewPos));


    glUniform1i(shader->useLight, 0);
    glBindBuffer(GL_ARRAY_BUFFER, shader->axesBuffer); //which buffer we want to use
	glEnableVertexAttribArray(shader->vertexLoc); //enable the attribute
	glVertexAttribPointer(
			shader->vertexLoc, //handle to variable in shader program
			3, //vector size (e.g. for texture coordinates this could be 2).
			GL_FLOAT, //what type of data is (e.g. GL_FLOAT, GL_INT, etc.)
			GL_FALSE, //normalize the data?
			0, //stride of data (e.g. offset in bytes). Most of the time leaving
			  //this at 0 (assumes data is in one, contiguous array) is fine
			  //unless we're doing something really complex.
			NULL //since our stride will be 0 in general, leaving this NULL is
			  //also fine in general
			);

	glBindBuffer(GL_ARRAY_BUFFER, shader->aNormalBuffer); //which buffer we want
	//to use
	glEnableVertexAttribArray(shader->normalLoc); //enable the attribute
	glVertexAttribPointer(
			shader->normalLoc, //handle to variable in shader program
			3, //vector size (e.g. for texture coordinates this could be 2).
			GL_FLOAT, //what type of data is (e.g. GL_FLOAT, GL_INT, etc.)
			GL_FALSE, //normalize the data?
			0, //stride of data (e.g. offset in bytes). Most of the time leaving
			  //this at 0 (assumes data is in one, contiguous array) is fine
			  //unless we're doing something really complex.
			NULL //since our stride will be 0 in general, leaving this NULL is
			  //also fine in general
			);


	glBindBuffer(GL_ARRAY_BUFFER, shader->aColorBuffer);
	glBufferData(
			GL_ARRAY_BUFFER,
			aColor.size() * sizeof(float),
			aColor.data(),
			GL_STATIC_DRAW
			);

    	glEnableVertexAttribArray(shader->colorLoc);
	glVertexAttribPointer(shader->colorLoc, 4, GL_FLOAT, GL_FALSE, 0, NULL);

    glUniform4f(shader->userColor, 1.0f, 1.0f, 1.0f, 1.0f);
	if(bBox) glDrawArrays(GL_LINES, 6, numAxes);

	//Have to reinsert the modelView matrix, as an identity matrix,
	//    in order to properly draw axes.
	modelCam = camera * axisView;
	glUniformMatrix4fv(
			shader->modelViewLoc, //handle to variable in the shader program
			1, //how many matrices we want to send
			GL_FALSE, //transpose the matrix
			glm::value_ptr(modelCam) //a pointer to an array containing the entries for
			  //the matrix
			);

    glUniform4f(shader->userColor, 1.0f, 0.0f, 0.0f, 1.0f);
    glDrawArrays(GL_LINES, 0, 2);
    glUniform4f(shader->userColor, 0.0f, 1.0f, 0.0f, 1.0f);
    glDrawArrays(GL_LINES, 2, 2);
    glUniform4f(shader->userColor, 0.0f, 0.0f, 1.0f, 1.0f);
    glDrawArrays(GL_LINES, 4, 2);

    modelCam = camera * modelView;
    glUniformMatrix4fv(
            shader->modelViewLoc, //handle to variable in the shader program
            1, //how many matrices we want to send
            GL_FALSE, //transpose the matrix
            glm::value_ptr(modelCam) //a pointer to an array containing the entries for
              //the matrix
            );

    glUniform1i(shader->useLight, 1);


    glBindBuffer(GL_ARRAY_BUFFER, shader->vertexBuffer); //which buffer we want
      //to use
    glBufferData(
                GL_ARRAY_BUFFER, //what kind of buffer (an array)
                verts2.size() * sizeof(float), //size of the buffer in bytes
                verts2.data(), //pointer to data we want to fill the buffer with
                GL_DYNAMIC_DRAW //how we intend to use the buffer
                );
    glEnableVertexAttribArray(shader->vertexLoc); //enable the attribute
    glVertexAttribPointer(
            shader->vertexLoc, //handle to variable in shader program
            3, //vector size (e.g. for texture coordinates this could be 2).
            GL_FLOAT, //what type of data is (e.g. GL_FLOAT, GL_INT, etc.)
            GL_FALSE, //normalize the data?
            0, //stride of data (e.g. offset in bytes). Most of the time leaving
              //this at 0 (assumes data is in one, contiguous array) is fine
              //unless we're doing something really complex.
            NULL //since our stride will be 0 in general, leaving this NULL is
              //also fine in general
            );
    glBindBuffer(GL_ARRAY_BUFFER, shader->normalBuffer); //which buffer we want
      //to use
    if(smoothShade){
		glBufferData(
			GL_ARRAY_BUFFER, //what kind of buffer (an array)
			sNorms.size() * sizeof(float), //size of the buffer in bytes
			sNorms.data(), //pointer to data we want to fill the buffer with
			GL_DYNAMIC_DRAW //how we intend to use the buffer
		);
	}
	else{
		glBufferData(
			GL_ARRAY_BUFFER, //what kind of buffer (an array)
			norms.size() * sizeof(float), //size of the buffer in bytes
			norms.data(), //pointer to data we want to fill the buffer with
			GL_DYNAMIC_DRAW //how we intend to use the buffer
		);
	}
    glEnableVertexAttribArray(shader->normalLoc); //enable the attribute
    glVertexAttribPointer(
            shader->normalLoc, //handle to variable in shader program
            3, //vector size (e.g. for texture coordinates this could be 2).
            GL_FLOAT, //what type of data is (e.g. GL_FLOAT, GL_INT, etc.)
            GL_FALSE, //normalize the data?
            0, //stride of data (e.g. offset in bytes). Most of the time leaving
              //this at 0 (assumes data is in one, contiguous array) is fine
              //unless we're doing something really complex.
            NULL //since our stride will be 0 in general, leaving this NULL is
              //also fine in general
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->colorBuffer);
        glBufferData(
                GL_ARRAY_BUFFER,
                color.size() * sizeof(float),
                color.data(),
                GL_DYNAMIC_DRAW
                );
    glEnableVertexAttribArray(shader->colorLoc);
    glVertexAttribPointer(shader->colorLoc, 4, GL_FLOAT, GL_FALSE, 0, NULL);

    glBindBuffer(GL_ARRAY_BUFFER, shader->texBuffer);
    	glBufferData(
    			GL_ARRAY_BUFFER,
    			texs.size() * sizeof(float),
    			texs.data(),
    			GL_STATIC_DRAW
    			);
        glEnableVertexAttribArray(shader->texCoordLoc);
        glVertexAttribPointer(shader->texCoordLoc, 2, GL_FLOAT, GL_FALSE, 0, NULL);

    //draw the vertices/normals we just specified.
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shader->indexBuffer);
    glDrawArrays(GL_TRIANGLES, 0, numVerts);


    //update animation variables.
    //have time oscillate between 0.0 and 1.0.
    if ((animTime >= 1.0 && deltaT > 0.0) ||
            (animTime <= 0.0 && deltaT < 0.0)) {
        deltaT = -deltaT;
    }

    glutSwapBuffers();
}

//idle function for GLUT
void idle() {
    glutPostRedisplay();
}

void selectAxis(int key)
{
	if(key == 1) {
		xSelect = xSelect ? false : true;
		scaleSelect = ySelect = zSelect = false;
	}
	if(key == 2) {
		ySelect = ySelect ? false : true;
		scaleSelect = xSelect = zSelect = false;
	}
	if(key == 3) {
		zSelect = zSelect ? false : true;
		scaleSelect = ySelect = xSelect = false;
	}
	if(key == 4) {
		scaleSelect = scaleSelect ? false : true;
		xSelect = ySelect = zSelect = false;
	}
}
//captures keyboard input for GLUT
//Sets variables for doing transforms
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    	case 27: exit(0); break;
    	case 98: bBox = bBox ? false : true; break;
    	case 102: smoothShade = smoothShade ? false : true; break;
    	case 99: cameraSelect = cameraSelect ? false : true; break;
    	case 114: modelView = defaultView; camera = defaultView2; break;
    	case 115: selectAxis(4); break;
    	case 120: selectAxis(1);  break;
    	case 121: selectAxis(2);  break;
    	case 122: selectAxis(3);  break;
    	default: break;
    }
}

//Callback for mouse button events.
//Sets variables for position and button state.
void mouse(int button, int state, int x, int y)
{
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN) {
			 mouseDownL = true;
			 glutPostRedisplay();
         }
         else if (state == GLUT_UP) {
			 mouseDownL = false;
 			 oldX = currX = oldY = currY = 0;
			 glutPostRedisplay();
         }
         break;
      case GLUT_RIGHT_BUTTON:
         if (state == GLUT_DOWN) {
        	 mouseDownR = true;
 			 glutPostRedisplay();
         }
         else if (state == GLUT_UP) {
 			 mouseDownR = false;
 			 oldX = currX = oldY = currY = 0;
 			 glutPostRedisplay();
         }
         break;
      default:
         break;
   }
   glutPostRedisplay();
}

//Callback for mouse movement while a button is down.
//Also applies transformations, as doing so in Display was causing the
//    transforms to slide, rather than just move.
void mouseMove(int x, int y){
	currX = x;
	currY = y;
	glutPostRedisplay();
}

//do some GLUT initialization
void setupGLUT() {
    glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA | GLUT_DOUBLE);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(WIN_WIDTH, WIN_HEIGHT);
    glutCreateWindow("3D Transform Program");

    glutReshapeFunc(reshape);

    glutDisplayFunc(display);

    glutKeyboardFunc(keyboard);

    glutMouseFunc(mouse);

    glutMotionFunc(mouseMove);

    glutIdleFunc(idle);
}

void addVert(float x, float y, float z)
{
	axes.push_back(x);
	axes.push_back(y);
	axes.push_back(z);
    aNorms.push_back(1);
    aNorms.push_back(1);
    aNorms.push_back(1);
}

void addTex(float x, float y)
{
	texs.push_back(x);
	texs.push_back(y);
}

void addColor(float x, float y, float z, float a)
{
    aColor.push_back(x);
    aColor.push_back(y);
    aColor.push_back(z);
    aColor.push_back(a);
}

void addEverything(){
	addVert(-5.0f,0.0f,0.0f);
	addColor(1.0f, 0.0f, 0.0f, 1.0f);
	addVert(5.0f,0.0f,0.0f);
	addColor(1.0f, 0.0f, 0.0f, 1.0f);
	addVert(0.0f,-5.0f,0.0f);
	addColor(0.0f, 1.0f, 0.0f, 1.0f);
	addVert(0.0f,5.0f,0.0f);
	addColor(0.0f, 1.0f, 0.0f, 1.0f);
	addVert(0.0f,0.0f,-5.0f);
	addColor(0.0f, 0.0f, 1.0f, 1.0f);
	addVert(0.0f,0.0f,5.0f);
	addColor(0.0f, 0.0f, 1.0f, 1.0f);

	addVert(maxpt.x,maxpt.y,maxpt.z);
	addVert(maxpt.x,maxpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,maxpt.y,maxpt.z);
	addVert(maxpt.x,minpt.y,maxpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,maxpt.y,maxpt.z);
	addVert(minpt.x,maxpt.y,maxpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,minpt.y,maxpt.z);
	addVert(maxpt.x,minpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,minpt.y,maxpt.z);
	addVert(minpt.x,minpt.y,maxpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,minpt.y,minpt.z);
	addVert(maxpt.x,maxpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,minpt.y,minpt.z);
	addVert(minpt.x,minpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(maxpt.x,maxpt.y,minpt.z);
	addVert(minpt.x,maxpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(minpt.x,minpt.y,minpt.z);
	addVert(minpt.x,minpt.y,maxpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(minpt.x,minpt.y,minpt.z);
	addVert(minpt.x,maxpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(minpt.x,maxpt.y,maxpt.z);
	addVert(minpt.x,minpt.y,maxpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);

	addVert(minpt.x,maxpt.y,maxpt.z);
	addVert(minpt.x,maxpt.y,minpt.z);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
	addColor(.05f, 0.5f, 0.5f, 1.0f);
}

//initialize OpenGL background color and vertex/normal arrays
void setupGL() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    addEverything();

	for (unsigned int i = 0; i < verts2.size(); i+=3){
		addTex((verts2[i] - (minpt.x))/(maxpt.x-minpt.x),
				(verts2[i+2] - (minpt.z))/(maxpt.z-minpt.z));
	}

	/*
    addTex(0.0, 0.0);
    addTex(0.0, 1.0);
    addTex(1.0, 1.0);
    addTex(1.0, 0.0);*/
    //addTex(0.0, 0.0);

	texture.loadFromFile("sharkcamo.jpg");
	texture.init();

    numAxes = axes.size() / 3;

    camera = glm::lookAt(glm::vec3(10,10,10), glm::vec3(0,0,0), glm::vec3(0,0,1));

    projection = glm::perspective(
            glm::float_t(45),
            glm::float_t(WIN_WIDTH) / glm::float_t(WIN_HEIGHT),
            glm::float_t(0.1),
            glm::float_t(1000.0)
    );

    defaultView = modelView;
    defaultView2 = camera;
}

//setup the shader program
void setupShaders() {
    //create the shader program from a vertex and fragment shader
    shader = new Shader("shaders/light.vert", "shaders/light.frag");

    //Here's where we setup handles to each variable that is used in the shader
    //program. See the shader source code for more detail on what the difference
    //is between uniform and vertex attribute variables.
    shader->modelViewLoc = glGetUniformLocation(shader->program, "M");
    shader->projectionLoc = glGetUniformLocation(shader->program, "P");
    shader->normalMatrixLoc = glGetUniformLocation(shader->program, "M_n");
    shader->timeLoc = glGetUniformLocation(shader->program, "time");
    shader->lightPosLoc = glGetUniformLocation(shader->program, "L_p");
    shader->viewPosLoc = glGetUniformLocation(shader->program, "E");
    shader->useLight = glGetUniformLocation(shader->program, "useLight");
    shader->userColor = glGetUniformLocation(shader->program, "userColor");
    shader->texArray = glGetUniformLocation(shader->program, "tex0");

    //notice that, since the vertex attribute norm is not used in the shader
    //program, shader->normalLoc = -1. If we access norm in the shader program,
    //then this value will be >= 0.
    shader->vertexLoc = glGetAttribLocation(shader->program, "pos");
    shader->normalLoc = glGetAttribLocation(shader->program, "norm");
    shader->colorLoc = glGetAttribLocation(shader->program, "color");
    shader->texCoordLoc = glGetAttribLocation(shader->program, "tex");

    //Create buffers for the vertex and normal attribute arrays
    GLuint bufs[8];
    glGenBuffers(8, bufs);

    shader->vertexBuffer = bufs[0];
    shader->normalBuffer = bufs[1];
    shader->colorBuffer = bufs[2];
    shader->axesBuffer = bufs[3];
    shader->aNormalBuffer = bufs[4];
    shader->aColorBuffer = bufs[5];
    shader->indexBuffer = bufs[6];
    shader->texBuffer = bufs[7];

    //This is where we pass the vertex/normal data to the GPU.
    //In general, the procedure for working with buffers is:
    //  1. Tell OpenGL which buffer we're using (glBindBuffer)
    //  2. Tell OpenGL what to do with the buffer (e.g. fill buffer, use the
    //     in the buffer, etc).
    //
    //Here we are filling the buffers (glBufferData). The last parameter
    //(GL_STATIC_DRAW), says that our intention is to not change the values in
    //these buffers. If we were going to be modifying these positions frequently
    //at runtime, we might want to make this GL_DYNAMIC_DRAW instead. For right
    //now, it's not too important which you choose.

    glBindBuffer(GL_ARRAY_BUFFER, shader->vertexBuffer);
    glBufferData(
            GL_ARRAY_BUFFER, //what kind of buffer (an array)
            verts2.size() * sizeof(float), //size of the buffer in bytes
            verts2.data(), //pointer to data we want to fill the buffer with
            GL_DYNAMIC_DRAW //how we intend to use the buffer
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->normalBuffer);
    glBufferData(
            GL_ARRAY_BUFFER,
            norms.size() * sizeof(float),
            norms.data(),
            GL_DYNAMIC_DRAW
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->colorBuffer);
    glBufferData(
            GL_ARRAY_BUFFER,
            color.size() * sizeof(float),
            color.data(),
            GL_DYNAMIC_DRAW
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->axesBuffer);
    glBufferData(
            GL_ARRAY_BUFFER, //what kind of buffer (an array)
            axes.size() * sizeof(float), //size of the buffer in bytes
            axes.data(), //pointer to data we want to fill the buffer with
            GL_DYNAMIC_DRAW //how we intend to use the buffer
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->aNormalBuffer);
    glBufferData(
            GL_ARRAY_BUFFER, //what kind of buffer (an array)
            aNorms.size() * sizeof(float), //size of the buffer in bytes
            aNorms.data(), //pointer to data we want to fill the buffer with
            GL_STATIC_DRAW //how we intend to use the buffer
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->aColorBuffer);
    glBufferData(
            GL_ARRAY_BUFFER,
            aColor.size() * sizeof(float),
            aColor.data(),
            GL_DYNAMIC_DRAW
            );

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shader->indexBuffer);
    glBufferData(
            GL_ELEMENT_ARRAY_BUFFER,
            indices.size() * sizeof(GLushort),
            indices.data(),
            GL_STATIC_DRAW
            );

    glBindBuffer(GL_ARRAY_BUFFER, shader->texBuffer);
    glBufferData(
            GL_ARRAY_BUFFER,
            texs.size() * sizeof(float),
            texs.data(),
            GL_STATIC_DRAW
            );
}

void readCoords(const char *filename )
{
    int     i, j;
    float   x, y, z;
    FILE    *f;

    minpt = glm::vec3(MAXFLOAT,MAXFLOAT,MAXFLOAT);
    maxpt = glm::vec3(MINFLOAT,MINFLOAT,MINFLOAT);

    f = fopen(filename, "r");
    if (!f)
    {
        cout << "Can not open the file " <<  filename << endl;
        exit(-1);
    }

    if (fscanf(f, "%d", &(numCoords)) != 1)
    {
        cout << "Can not read the first line of  " <<  filename << endl;
        exit(-1);
    }

    printf("NUMCOORDS %d\n", numCoords);

    for(i = 0; i < numCoords; i++)
    {

        if (fscanf(f, "%d,%f,%f,%f", &j, &x, &y, &z) != 4)
        {
        	cout << "Can't read from " << endl;
            exit(-1);
        }
        if ((j < 0) || (j > numCoords))
        {
        	cout << "Illegal index" << endl;
            exit(-1);
        }

        if (x > maxpt[0]) maxpt[0] = x;
        if (x < minpt[0]) minpt[0] = x;
        if (y > maxpt[1]) maxpt[1] = y;
        if (y < minpt[1]) minpt[1] = y;
        if (z > maxpt[2]) maxpt[2] = z;
        if (z < minpt[2]) minpt[2] = z;

        verts.push_back(x);
        verts.push_back(y);
        verts.push_back(z);
    }

    fclose(f);

    centerpt[0] =(maxpt[0] + minpt[0])/2;
    centerpt[1] =(maxpt[1] + minpt[1])/2;
    centerpt[2] =(maxpt[2] + minpt[2])/2;

    cout << "verts2 size = " << verts.size()/3 << endl;

}

void addToMap(int i, glm::vec3 vec)
{
	glm::vec3 oldVec;
	//map<int,glm::vec3>::iterator it;
	//it = normMap.find(i);
	//normMap.insert(pair<int, glm::vec3>(i, vec));
	//if (it == normMap.end())
	//else normMap[i] += vec;

	pair<map<int,glm::vec3>::iterator,bool> isThere;
	normMap.insert ( pair<int,glm::vec3>(i,vec) );
	isThere=normMap.insert (pair<int,glm::vec3>(i,vec) );
	if (isThere.second==false) normMap[i] += vec;

	//cout << normMap[i].x << ", " << normMap[i].y << ", " << normMap[i].z << endl;
}

// read .poly files
void  readPolygons(const char *filename)
{
	//pairs.assign(696, 0);
	//pairs.resize(696);
    int     i;
    int pnt;
    int res;
    int ind;
    char    c;
    FILE    *f;
    int temp;
    int prev;

    glm::vec3 vec1, vec2, vec3;
    cout << "inside read poly " << endl;

    f = fopen(filename, "r");
    if (!f)
    {
    	cout << "Can't read the file " <<  filename << endl;
    	exit(-1);
    }
    if ( fscanf(f, "%d", &(numPolygons)) != 1)
    {
    	cout << "Can't read first line of " <<  filename << endl;
    	exit(-1);
    }

    cout << verts.size()/3 << " = num coords" << endl;
    cout << numPolygons << " num poly" << endl;

    for(i = 0; i < numPolygons; i++)
    {
        do
            c = fgetc(f);
        while(!feof(f) && (c != ' '));
        ind = 0;

        do
        {
            res = fscanf(f, "%d", &pnt);
        	if (res && ind >= 3)
        	{
        	    indices.push_back(temp-1);
        	    indices.push_back(prev-1);
        	    verts2.push_back(verts[(temp-1)*3]);
        	    verts2.push_back(verts[((temp-1)*3)+1]);
        	    verts2.push_back(verts[((temp-1)*3)+2]);
        	    verts2.push_back(verts[(prev-1)*3]);
        	    verts2.push_back(verts[((prev-1)*3)+1]);
        	    verts2.push_back(verts[((prev-1)*3)+2]);
                color.push_back(0.8);color.push_back(0.8);color.push_back(0.8);color.push_back(1);
                color.push_back(0.8);color.push_back(0.8);color.push_back(0.8);color.push_back(1);

				vec1.x=(verts[(temp-1)*3]);
				vec1.y=(verts[((temp-1)*3)+1]);
				vec1.z=(verts[((temp-1)*3)+2]);
				vec2.x=(verts[(prev-1)*3]);
				vec2.y=(verts[((prev-1)*3)+1]);
				vec2.z=(verts[((prev-1)*3)+2]);
				vec3.x=(verts[(pnt-1)*3]);
				vec3.y=(verts[((pnt-1)*3)+1]);
				vec3.z=(verts[((pnt-1)*3)+2]);
				addToMap(temp-1, vec3);
                addToMap(temp-1, vec2);
                addToMap(prev-1, vec1);
                addToMap(prev-1, vec3);
                addToMap(pnt-1, vec1);
                addToMap(pnt-1, vec2);
        	}
            if (res)
            {
            	indices.push_back(pnt-1);
        	    verts2.push_back(verts[(pnt-1)*3]);
        	    verts2.push_back(verts[((pnt-1)*3)+1]);
        	    verts2.push_back(verts[((pnt-1)*3)+2]);
                color.push_back(0.8);color.push_back(0.8);color.push_back(0.8);color.push_back(1);

                if (ind == 0)
                	{
                		temp = pnt;
                	}
                prev = pnt;
                ind++;
            }
            if (ind >= MAX_PTS)
			{
				cout << "Too many indices\n";
				cout << "polygon "<<  i << endl;
				exit(-1);
			}
        }
        while(!feof(f) && res);
    }

    fclose(f);
    cout <<" Number of polygons " << numPolygons << endl;
}

void load()
{
    readCoords("surfboard.coor");
    cout << "read coords file successfully" << endl;
    readPolygons("surfboard.poly");
    cout << "read surfboard file successfully" << endl;

    numIndex = indices.size();
    numVerts = verts2.size()/3;
}

void calcSmoothNorms(){
	glm::vec3 normal;

	for (unsigned int i = 0; i < numVerts; i++)
	{

		normal = glm::normalize(normMap[i]);

		//cout << normal.x << ", " << normal.y << ", " << normal.z << endl;

		sNorms.push_back(normal.x);
		sNorms.push_back(normal.y);
		sNorms.push_back(normal.z);
	}
}

void calcNorms()
{
	glm::vec3 normal, Qv, Pv;
	for (unsigned int i = 0; i < verts2.size(); i+=9)
	{
		Qv.x = verts2[i] - verts2[i+3];
		Qv.y = verts2[i+1] - verts2[i+4];
		Qv.z = verts2[i+2] - verts2[i+5];

		Pv.x = verts2[i+6] - verts2[i+3];
		Pv.y = verts2[i+7] - verts2[i+4];
		Pv.z = verts2[i+8] - verts2[i+5];

		normal = glm::cross(Pv, Qv);
		normal = glm::normalize(normal);

		norms.push_back(normal.x);
		norms.push_back(normal.y);
		norms.push_back(normal.z);
		norms.push_back(normal.x);
		norms.push_back(normal.y);
		norms.push_back(normal.z);
		norms.push_back(normal.x);
		norms.push_back(normal.y);
		norms.push_back(normal.z);

		//addToMap(i, normal);
		//addToMap(i+3, normal);
		//addToMap(i+6, normal);

	}
}

int main(int argc, char **argv) {
	load();
	calcNorms();
	calcSmoothNorms();
    glutInit(&argc, argv);
    setupGLUT();
    setupGL();

    smoothShade = false;
	xSelect = false;
    oldX = oldY = 0;

    glewInit();

    setupShaders();

    glutMainLoop();

    if (shader) delete shader;

    return 0;
}

