Justin Barrica
jbarrica@ucsc.edu

Compiled/Run on Eclipse using the standard lab equipment using elements from the lab4 showcase solution.

I successfully implemented diffuse shading, hidden surface elimination, specular lighting, and texture mapping.
I attempted the smooth normal calculations but was unable to get it working correctly. I understand the concept
of averaging the polygon normals but had trouble correctly adding the right vectors' normals. I did not attempt
the bump mapping.

Despite incorrect smooth normal calculations, you can see the results by pressing the 'f' key.

I'm still unable to create a working statically linked executable from Eclipse, but you should be able to run the
program by setting prog4/workspace160 as the Eclipse workspace.