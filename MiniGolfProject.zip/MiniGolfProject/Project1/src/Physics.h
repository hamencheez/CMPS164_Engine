#pragma once

#include <vector>
#include <iostream>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "Ball.h"

#define PI 3.141592653589793

/* NOTE: This class is very much untested at the moment
 * none of what's in here is guaranteed to work, don't be afraid
 * to completely change structure, etc.
*/

class Physics {
private:
	double gravityConstant;
	double frictionConstant;
	int currentTime;

public:

	Physics() {
		gravityConstant = 0.001;
		frictionConstant = 0.995;
		currentTime = clock();
	}

	//We can construct a plane out of the normal in the equation
	//P => ax + by + c = ax1 + by1 + cz1
	//Where (a,b,c) is the normal, (x1,y1,z1) is a known point on the plane
	//and (x,y,z) is the point we want. We know x and z, so we solve for y to find the height
	float Physics::getHeightOfPointOnPlaneViaNormal(Vector3* tileNorm, Vector3* pt, float x, float z) {
		float height = 0.0;
		float tempX = tileNorm->getX() * (pt->getX() - x);
		float tempY = tileNorm->getY() * pt->getY();
		float tempZ = tileNorm->getZ() * (pt->getZ() - z);
		height = (tempX + tempY + tempZ) / tileNorm->getY();
		return height;
	}

	Vector3* Physics::applyForces(Vector3 *velocity, float angle, Vector3 *down) {
		//First we want to apply friction
		velocity = velocity->multiply(frictionConstant);

		//Then we want to calculate gravity
		//Moved initial down vector calculation to tile constructor ->

		/*
		//Using the tile normal, we can dot the normal with (0, 1, 0), or the up direction
		//The result will be 90 - theta, where theta is our incline
		//Since (0, 1, 0) is very simple, we are reduced down to
		//   theta = 90 - acos(N.y/N.length)
		float theta = acos(tileNormal->getY()/tileNormal->getLength());
		
		//Convert to degrees
		theta = (theta * 180) / PI;
		//theta = 90 - theta;
		//std::cout <<"Angle is " << theta <<std::endl;

		//Now we know how much gravity affects the ball, so we calculate the
		//amount of force by gravity by gravity * sin(theta)
		float gravity = gravityConstant * sin(theta);

		//std::cout <<"Gravity is " << gravity <<std::endl;

		//Lastly, we need to know the downwards facing vector so we know
		//which direction to inact gravity upon
		//To d this, we cross gravity with our normal to get a vector that is
		//90 degrees to the side. Then crossing the normal with that vector
		//results in our vector
		Vector3 *gravityDirection = new Vector3(0, -1, 0);
		gravityDirection = tileNormal->cross(gravityDirection);
		gravityDirection = gravityDirection->cross(tileNormal);
		
		gravityDirection = gravityDirection->normalize();

		if (tileNormal->getX() !=0 && tileNormal->getZ() != 0) gravityDirection = gravityDirection->multiply(-1);

		//Apply our gravity factor to the normalize direction vector
		gravityDirection = gravityDirection->multiply(gravity);

		//Now apply it to our ball's velocity
		ball->velocity = ball->velocity->add(gravityDirection);
		ball->velocity->setY(0); */

		float gravity = abs(gravityConstant * sin(angle));
		//if (gravity != 0)
		//	std::cout <<"Gravity is " << gravity << std::endl;
		Vector3 *gForce =  down->multiply(gravity);
		velocity = velocity->add(gForce);
		velocity->setY(0);

		return velocity;
	}

	//Used the algorithm for point on plane from
	//http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
	bool Physics::pointOnPlane(std::vector<float> xVertex, std::vector<float> zVertex, float x, float z) {
		unsigned int curr = 0;
		unsigned int prev = xVertex.size() - 1;

		bool pointOnPlane = false;

		for (; curr < xVertex.size(); curr++) {
			if (((zVertex.at(curr) > z) != (zVertex.at(prev) > z)) && 
				(x < (xVertex.at(prev) - xVertex.at(curr)) * (z - zVertex.at(curr)) / (zVertex.at(prev) - zVertex.at(curr)) + xVertex.at(curr))) {
					pointOnPlane = !pointOnPlane;
			}
			prev = curr;
		}
		return pointOnPlane;
	}

	bool Physics::pointOnLine(float x1, float y1, float x2, float y2, float x, float y) {
		//Given two points, form a line between them
		//then check if (x, y) is a valid point
		float slope = (y2 - y1) / (x2 - x1);
		float tempY = (slope * (x - x1)) + y1;
		if (tempY == y) return true;
		if (abs(tempY - y) < 0.2) return true;

		//Test: See if we need to check the other way too
		slope = 1 / slope;
		float tempX = (slope * (y - y1)) + x1;
		if (tempX == x) return true;
		if (abs(tempX - x) < 0.2) return true;
		return false;
	}

	Vector3* Physics::calculateReflection(float x1, float z1, float x2, float z2, Vector3* ball) {
		//First, calculate the normal based on the passed in points
		Vector3 *v1 = new Vector3(x1 - x2, 0, z1 - z2);
		Vector3 *v2 = new Vector3(0, 1, 0);
		Vector3 *normal = v1->cross(v2);
		normal = normal->normalize();
		std::cout <<"Normal is (" << normal->getX() << ", " << normal->getY() << ", " << normal->getZ() << ")" <<std::endl;

		float scalar = 2 * ball->dot(normal);
		normal = normal->multiply(scalar);
		Vector3 *result = ball->subtract(normal);

		delete v1;
		delete v2;
		delete normal;
		return result;
	}

	Vector3* Physics::calculateReflection(Vector3 *normal, Vector3 *ball) {
		std::cout <<"Normal is (" << normal->getX() << ", " << normal->getY() << ", " << normal->getZ() << ")" <<std::endl;
		float scalar = 2 * ball->dot(normal);
		normal = normal->multiply(scalar);
		Vector3 *result = ball->subtract(normal);

		return result;
	}

	float Physics::minNumber(std::vector<float> data) {
		float min = 999999;
		for (int itor = 0; itor < data.size(); ++itor) {
			if (data.at(itor) < min) min = data.at(itor);
		}
		return min;
	}

	float Physics::maxNumber(std::vector<float> data) {
		float max = -999999;
		for (int itor = 0; itor < data.size(); ++itor) {
			if (data.at(itor) > max) max = data.at(itor);
		}
		return max;
	}
};